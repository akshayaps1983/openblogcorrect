from django import forms 
from account.models import* 


class ProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        exclude=['user']

class CPassForm(forms.Form):
    old_pass=forms.CharField(max_length=100,label="old password",widget=forms.PasswordInput(attrs={"class":"form_control","placeholder":"Enter old Password"}))
    new_pass=forms.CharField(max_length=100,label="new password",widget=forms.PasswordInput(attrs={"class":"form_control","placeholder":"Enter new Password"}))
    cnf_pass=forms.CharField(max_length=100,label="confirm password",widget=forms.PasswordInput(attrs={"class":"form_control","placeholder":"Re enter new Password"}))

class BlogForm(forms.ModelForm):
    class Meta:
        model=Blogs
        fields=["title","description","image"]
        widgets={
            "title":forms.TextInput(attrs={"class":"form_control"}),
            "description":forms.Textarea(attrs={"class":"form_control"}),
            "image":forms.FileInput(),
        }
class EditForm(forms.ModelForm):
    class meta:
        model=Blogs
        exclude=['user']


class CommentForm(forms.ModelForm):
    class Meta:
        model =comments
        fields = ["comment"]
        widget={
    
            "comment":forms.Textarea(attrs={"class":"form-control"})
        }